# 계산기!! 
def add_two_number(num1, num2):
    return num1 + num2

def sub_two_number(num1, num2):
    return num1 - num2

def mul_two_number(num1, num2):
    return num1 * num2

def div_two_number(num1, num2):
    return num1 / num2