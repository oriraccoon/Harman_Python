# 생성자 (Constructor)
# 클래스 생성 시 자동으로 호출되는 함수!!
class Addr():
    def __init__(self, name, age, tel):
        self.name = name
        self.age = age
        self.tel = tel

    def show_addr(self):
        print(f"이름 : {self.name}, 나이 : {self.age}, 연락처 : {self.tel}")